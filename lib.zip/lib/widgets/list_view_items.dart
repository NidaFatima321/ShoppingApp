import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/courier_shipment.dart';
import 'package:flutter_application_1/widgets/dialog_box.dart';

class ListViewItems extends StatelessWidget {
  final String nic;
  final String category;
  final int count;
  final Shipment data;

  final Function() onDeliver;
  final Function() onUnDeliver;

  const ListViewItems({
    Key? key,
    required this.nic,
    required this.category,
    required this.count,
    required this.onDeliver,
    required this.onUnDeliver,
    required this.data,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(0, 10, 0, 10),
      padding: const EdgeInsets.all(10.0),
      decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(left: BorderSide(color: Colors.blue, width: 2.0))),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text(
                    nic,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(width: 50.0),
                  Text(
                    category,
                    style: const TextStyle(color: Colors.blue),
                  ),
                ],
              ),
              Text('$count')
            ],
          ),
          const SizedBox(
            height: 20.0,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('-'),
              Row(
                children: [
                  const Icon(Icons.phone),
                  const Icon(Icons.location_city),
                  GestureDetector(
                      onTap: () {
                        showDialog(
                            context: context,
                            builder: (context) => DialogBox(courierData: data));
                      },
                      child: const Icon(Icons.info))
                ],
              )
            ],
          ),
          const SizedBox(
            height: 20.0,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Icon(Icons.location_history_rounded),
              ElevatedButton(
                  onPressed: onDeliver, child: const Text("Delivered")),
              ElevatedButton(
                  onPressed: onUnDeliver, child: const Text("UnDelivered")),
              const Icon(Icons.play_circle_fill_outlined)
            ],
          )
        ],
      ),
    );
  }
}
