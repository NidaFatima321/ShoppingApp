import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/courier_shipment.dart';

class DialogBox extends StatelessWidget {
  // final String consigneeName;
  // final String consigneePhone;
  // final String consigneeAdd;
  // final String pieces;
  // final String weight;
  // final String origin;
  // final String destination;
  // final String recieverName;
  // final String delAdd;
  // final String reason;
  // final String codAmount;
  final Shipment courierData;

  const DialogBox({
    super.key,
    required this.courierData,
    // required this.consigneeName,
    // required this.consigneePhone,
    // required this.consigneeAdd,
    // required this.pieces,
    // required this.weight,
    // required this.origin,
    // required this.destination,
    // required this.recieverName,
    // required this.delAdd,
    // required this.reason,
    // required this.codAmount,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 355,
              color: Colors.amber,
              child: const Text(
                "SHIPMENT DETAILS",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(
              height: 30.0,
            ),
            const Text(
              "CONSIGNEE NAME",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Text(courierData.consignmentName ?? "-"),
            const SizedBox(
              height: 20.0,
            ),
            const Text(
              "CONSIGNEE PHONE",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Text(courierData.consignmentPhone ?? "-"),
            const SizedBox(
              height: 20.0,
            ),
            const Text(
              "CONSIGNEE ADDRESS",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Text(courierData.consignmentAddress ?? "-"),
            const SizedBox(
              height: 20.0,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    const Text(
                      "PIECES",
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Text('${courierData.pcs}')
                  ],
                ),
                Column(
                  children: [
                    const Text(
                      "WEIGHT (GRAMS)",
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Text('${courierData.weight}')
                  ],
                )
              ],
            ),
            const SizedBox(
              height: 20.0,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    const Text(
                      "ORIGIN",
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Text('${courierData.arvlOrigin}')
                  ],
                ),
                Column(
                  children: [
                    const Text(
                      "DESTINATION",
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Text('${courierData.arvlDest}')
                  ],
                )
              ],
            ),
            const SizedBox(
              height: 20.0,
            ),
            const Text(
              "RECEIVER NAME",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const Text("-"),
            const SizedBox(
              height: 20.0,
            ),
            const Text(
              "DELIVERY ADDRESS",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const Text("-"),
            const SizedBox(
              height: 20.0,
            ),
            const Text(
              "REASON",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const Text("-"),
            const SizedBox(
              height: 20.0,
            ),
            const Text(
              "COD AMOUNT",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Text('${courierData.arvLTime}')
          ],
        ),
      ),
    );
  }
}
