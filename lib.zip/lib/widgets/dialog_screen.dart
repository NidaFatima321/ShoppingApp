import 'package:flutter/material.dart';

class DialogScreen extends StatelessWidget {
  const DialogScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Container(
            height: 50.0,
            color: Colors.white,
            child: Column(children: const [
              Text(
                "Hello World",
                style: TextStyle(color: Colors.black),
              ),
            ])));
  }
}
