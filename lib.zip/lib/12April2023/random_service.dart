import 'package:http/http.dart' as http;

import '../models/random_model.dart';

class RandomService {
  Future<RandomUser> getRandom() async {
    var client = http.Client();
    try {
      var response =
          await client.get(Uri.parse('https://randomuser.me/api/?results=10'));

      // print(response.body);
      RandomUser posts = randomUserFromJson(response.body);
      return posts;
    } finally {
      client.close();
    }
  }
}
