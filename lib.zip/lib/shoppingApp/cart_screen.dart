import 'package:flutter/material.dart';
import 'package:flutter_application_1/shoppingApp/final_screen.dart';
import 'package:flutter_application_1/shoppingApp/list_view_widget.dart';
import 'package:get/get.dart';

import '../controllers/shopping_controller.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  ShoppingController usersController = Get.find<ShoppingController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Cart"),
        centerTitle: true,
      ),
      // body: Text("Hello"),
      body: Column(
        children: [
          Expanded(
            child: Obx(() {
              return ListView.builder(
                itemCount: usersController.cartItems.length,
                itemBuilder: (context, index) {
                  return Column(children: [
                    ListViewWidget(
                      product: usersController.cartItems[index],
                      func: () {
                        usersController.cartItems
                            .remove(usersController.cartItems[index]);
                      },
                      text: "Remove From Cart",
                    ),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          ElevatedButton(
                              onPressed: () {
                                usersController.cartItems[index].quantity -= 1;
                                usersController.cartItems.refresh();
                              },
                              child: const Text("-1")),
                          Text("${usersController.cartItems[index].quantity}"),
                          ElevatedButton(
                              onPressed: () {
                                usersController.cartItems[index].quantity += 1;
                                usersController.cartItems.refresh();
                              },
                              child: const Text("+1"))
                        ]),
                  ]);
                },
              );
            }),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              const Text(
                "CART SUBTOTAL",
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.bold),
              ),
              Obx(() {
                return Text(
                    '${usersController.cartItems.fold(0, (previousValue, element) => previousValue + element.price * element.quantity)}');
              })
            ],
          ),
          ElevatedButton.icon(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => const FinalScreen(),
                ));
              },
              icon: const Icon(Icons.home),
              label: const Text("CHECKOUT"))
        ],
      ),
    );
  }
}
