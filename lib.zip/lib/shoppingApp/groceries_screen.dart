import 'package:flutter/material.dart';
import 'package:flutter_application_1/shoppingApp/list_view_widget.dart';
import 'package:get/get.dart';

import '../controllers/shopping_controller.dart';

class Groceries extends StatefulWidget {
  const Groceries({super.key});

  @override
  State<Groceries> createState() => _GroceriesState();
}

class _GroceriesState extends State<Groceries>
    with AutomaticKeepAliveClientMixin {
  ShoppingController usersController = Get.find<ShoppingController>();

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return ListView.builder(
      shrinkWrap: true,
      itemCount: usersController.shoppingList3.length,
      itemBuilder: (context, index) {
        return SizedBox(
          height: 200,
          child: ListViewWidget(
            product: usersController.shoppingList3[index],
            func: () {
              usersController.cartItems
                  .add(usersController.shoppingList3[index]);
              usersController.total = usersController.total +
                  usersController.cartItems[index].price;
              setState(() {});
            },
            text: 'Add to Cart',
          ),
        );
      },
    );
  }

  @override
  bool get wantKeepAlive => true;
}
