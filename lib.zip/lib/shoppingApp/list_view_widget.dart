import 'package:flutter/material.dart';
import 'package:flutter_application_1/shoppingApp/image_dialog.dart';
import 'package:get/get.dart';

import '../controllers/shopping_controller.dart';
import '../models/shopping_model.dart';

class ListViewWidget extends StatefulWidget {
  final Product product;
  final String text;
  final Function() func;
  const ListViewWidget(
      {super.key,
      required this.product,
      required this.func,
      required this.text});

  @override
  State<ListViewWidget> createState() => _ListViewWidgetState();
}

class _ListViewWidgetState extends State<ListViewWidget> {
  ShoppingController usersController = Get.find<ShoppingController>();
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        showDialog(
          context: context,
          builder: (context) => ImageDialog(product: widget.product),
        );
      },
      child: Container(
        margin: const EdgeInsets.all(8),
        padding: const EdgeInsets.all(5),
        color: Colors.white,
        child: Row(
          // crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Flexible(
              flex: 2,
              child: Image.network(
                widget.product.thumbnail,
                // width: 80,
                // height: double.maxFinite,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 7),
            Flexible(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.product.title,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                      width: 250,
                      height: 50,
                      child: Text(widget.product.description)),
                  Row(
                    children: [
                      Text(
                        '\$ ${widget.product.price}',
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      Text(
                        '${widget.product.discountPercentage} %',
                        style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            color: Colors.red,
                            fontFamily: "Times New Roman"),
                      )
                    ],
                  ),
                  Text(widget.product.brand),
                  ElevatedButton.icon(
                      onPressed: widget.func,
                      // onPressed: () {
                      //   usersController.cartItems.add(widget.product);
                      // },
                      icon: const Icon(Icons.shop),
                      label: Text(widget.text))
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
