import 'package:flutter/material.dart';
import 'package:flutter_application_1/shoppingApp/list_view_widget.dart';
import 'package:get/get.dart';

import '../controllers/shopping_controller.dart';

class Laptops extends StatefulWidget {
  const Laptops({super.key});

  @override
  State<Laptops> createState() => _LaptopsState();
}

class _LaptopsState extends State<Laptops> with AutomaticKeepAliveClientMixin {
  ShoppingController usersController = Get.find<ShoppingController>();

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return ListView.builder(
      shrinkWrap: true,
      itemCount: usersController.shoppingList2.length,
      itemBuilder: (context, index) {
        return SizedBox(
          height: 200,
          child: ListViewWidget(
            product: usersController.shoppingList2[index],
            func: () {
              usersController.cartItems
                  .add(usersController.shoppingList2[index]);
              usersController.total = usersController.total +
                  usersController.cartItems[index].price;
              setState(() {});
            },
            text: 'Add to Cart',
          ),
        );
      },
    );
  }

  @override
  bool get wantKeepAlive => true;
}
