import 'package:flutter/material.dart';
import 'package:flutter_application_1/main.dart';
import 'package:flutter_application_1/models/courier_shipment.dart';

import 'package:flutter_application_1/widgets/cards.dart';

import 'delivered.dart';
import 'inprocess.dart';
import 'undelivered.dart';

class NewComp extends StatelessWidget {
  final CourierShipment courierShipment;
  final PageController pageController = PageController();

  NewComp({super.key, required this.courierShipment});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              "TASKS",
              style: TextStyle(color: Colors.black),
            ),
            ClipRRect(
                borderRadius: BorderRadius.circular(50.0),
                child: ElevatedButton(
                  onPressed: () {},
                  child: const Text("RE ROUTE"),
                ))
          ],
        ),
      ),
      body: LayoutBuilder(builder: (context, constraints) {
        return Column(
          children: [
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  GestureDetector(
                      onTap: () {
                        pageController.animateToPage(0,
                            duration: const Duration(milliseconds: 500),
                            curve: Curves.ease);
                      },
                      child: Cards(
                          text: "IN PROCESS",
                          count: courierShipment.data.length,
                          colors: Colors.blue)),
                  GestureDetector(
                    onTap: () {
                      pageController.animateToPage(1,
                          duration: const Duration(milliseconds: 500),
                          curve: Curves.ease);
                    },
                    child: Cards(
                      text: "DELIVERED",
                      count: delivered.length,
                      colors: Colors.white,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      pageController.animateToPage(2,
                          duration: const Duration(milliseconds: 500),
                          curve: Curves.ease);
                    },
                    child: Cards(
                      text: "UNDELIVERED",
                      count: undelivered.length,
                      colors: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                    child: Container(
                  margin: const EdgeInsets.symmetric(
                      vertical: 5.0, horizontal: 7.0),
                  child: const TextField(
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: "Search Here (Enter CN Number)",
                        filled: true,
                        fillColor: Colors.white),
                  ),
                )),
                const Icon(
                  Icons.cancel,
                  size: 40,
                  color: Colors.blue,
                )
              ],
            ),
            Expanded(
              child: PageView(
                controller: pageController,
                children: [
                  InProcess(
                    courierShipment: courierShipment,
                  ),
                  Delivered(data: courierShipment),
                  Undelivered(
                    data: courierShipment.data[0],
                  )
                ],
              ),
            ),
            Container(
              color: Colors.amber[300],
              width: constraints.maxWidth,
              child: const Text(
                "Version 1.0 - Live",
                textAlign: TextAlign.center,
              ),
            )
          ],
        );
      }),
    );
  }
}
