import 'package:flutter/material.dart';
import 'package:flutter_application_1/main.dart';

import '../models/courier_shipment.dart';
import '../widgets/list_view_items.dart';

class InProcess extends StatefulWidget {
  final CourierShipment courierShipment;
  const InProcess({super.key, required this.courierShipment});

  @override
  State<InProcess> createState() => _InProcessState();
}

class _InProcessState extends State<InProcess> {
  // CourierService courierService = CourierService();
  // late CourierShipment data;
  bool dataLoaded = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: ListView.builder(
      padding: const EdgeInsets.all(8.0),
      itemCount: 10,
      itemBuilder: (context, index) {
        CourierShipment courierData = widget.courierShipment;
        return GestureDetector(
          onTap: () {
            // showDialog(
            //   context: context,
            //   builder: (context) => DialogScreen(),
            // );
          },
          child: ListViewItems(
            category: courierData.data[index].product.name,
            count: index,
            nic: courierData.data[index].cNNumber ?? "N/A",
            onDeliver: () {
              delivered.add(courierData.data[index]);
              courierData.data.removeAt(index);
              setState(() {});
            },
            onUnDeliver: () {
              undelivered.add(courierData.data[index]);
              courierData.data.removeAt(index);
              setState(() {});
            },
            data: courierData.data[index],
          ),
        );
      },
    ));
  }

  // void getCourierData() async {
  //   data = await courierService.getCourier();
  //   dataLoaded = true;
  //   setState(() {});
  // }
}
