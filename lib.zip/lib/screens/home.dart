import 'package:flutter/material.dart';
import 'package:flutter_application_1/screens/main_screen.dart';

import '../models/courier_shipment.dart';
import '../models/token_model.dart';
import '../services/courier_service.dart';

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  CourierService courierService = CourierService();
  late CourierShipment data;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    getCourierData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.grey[200],
        appBar: AppBar(
          backgroundColor: Colors.orange,
          title: Image.asset('assets/lep.png', width: 100.0),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.fromLTRB(30, 30, 30, 0),
          child: loading
              ? const CircularProgressIndicator()
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      "Hi, Please Enter Your Courier Code",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10.0),
                    const Text("Please Ensure Your Courier Code is Active"),
                    const SizedBox(height: 30.0),
                    const Text("Enter Your Coureir Code"),
                    const SizedBox(height: 10.0),
                    const TextField(
                      decoration: InputDecoration(
                          border: InputBorder.none,
                          labelText: "XXXX",
                          filled: true,
                          fillColor: Colors.white),
                    ),
                    Column(
                      children: const [
                        SizedBox(height: 20.0),
                        Text("Hub Information"),
                        Text("00592 - BRANCH OFFICE KARACHI")
                      ],
                    ),
                    const SizedBox(height: 60.0),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => MainScreen(
                            courierShipment: data,
                          ),
                        ));
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.amber,
                          foregroundColor: Colors.black),
                      child: const Text("Login"),
                    )
                  ],
                ),
        ));
  }

  void getCourierData() async {
    Token token = await courierService.getToken();
    data = await courierService.getCourier(token.token);
    loading = false;
    setState(() {});
  }
}
