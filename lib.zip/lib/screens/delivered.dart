import 'package:flutter/material.dart';
import 'package:flutter_application_1/main.dart';

import '../models/courier_shipment.dart';
import '../widgets/list_view_items.dart';

class Delivered extends StatefulWidget {
  final CourierShipment data;
  const Delivered({super.key, required this.data});

  @override
  State<Delivered> createState() => _DeliveredState();
}

class _DeliveredState extends State<Delivered> {
  List<Shipment> del = delivered;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView.builder(
        padding: const EdgeInsets.all(8.0),
        itemCount: delivered.length,
        itemBuilder: (context, index) {
          return ListViewItems(
            category: del[index].product.name,
            count: index,
            nic: '${del[index].cNNumber}',
            onDeliver: () {},
            onUnDeliver: () {},
            data: widget.data.data[0],
          );
        },
      ),
    );
  }
}
