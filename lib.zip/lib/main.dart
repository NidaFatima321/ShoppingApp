import 'package:flutter/material.dart';

import 'models/courier_shipment.dart';
import 'shoppingApp/home_screen.dart';

void main() => runApp(const MaterialApp(
      home: ShoppingScreen(),
    ));

List<Shipment> delivered = [];
List<Shipment> undelivered = [];
